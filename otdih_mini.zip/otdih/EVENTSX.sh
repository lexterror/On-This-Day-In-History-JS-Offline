#!/bin/sh
i=1
j=1
while [ $j -ne 13 ]
do
while [ $i -ne 32 ]
do
        name=$j.$i.txt
        curl https://api.wikimedia.org/feed/v1/wikipedia/en/onthisday/events/$j/$i | jq '.events[] | "\(.year) ':' \(.text)"' >> $name
        i=$(($i+1))
done
        j=$(($j+1))
        i=1
done
